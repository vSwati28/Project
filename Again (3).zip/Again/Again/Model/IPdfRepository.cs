﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Again.Model
{
    public interface IPdfRepository<Pdf>
    {
        IEnumerable<Pdf> GetAllPdf();
        Pdf ReadPdf(string Path);
    }
}
