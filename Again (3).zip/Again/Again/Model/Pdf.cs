﻿using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Again.Model
{
    public class Pdf
    {
        [Key]

        public string PdfId { get; set; }

        public string Path { get; set; }

        
        
    }
}
