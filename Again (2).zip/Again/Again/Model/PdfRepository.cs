﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Again.Model
{
    public class PdfRepository: IPdfRepository<Pdf>
    {
        readonly PdfContext _pdfContext;


        public PdfRepository(PdfContext context)
        {
            _pdfContext = context;
        }
        public IEnumerable<Pdf> GetAllPdf()
        {
            return _pdfContext.Pdfs.ToList();
        }

    }
}

