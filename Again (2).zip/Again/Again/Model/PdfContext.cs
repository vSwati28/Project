﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Again.Model
{
    public class PdfContext:DbContext
    {
        public PdfContext(DbContextOptions<PdfContext> options) : base(options)
        {
            Database.Migrate();
        }
        public DbSet<Pdf> Pdfs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Pdf>().HasData(new Pdf
            {
                PdfId = "1"

            }); 
        }
    }
}