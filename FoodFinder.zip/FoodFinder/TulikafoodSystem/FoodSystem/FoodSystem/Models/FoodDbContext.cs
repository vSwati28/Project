﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace FoodSystem.Models
{
    public class FoodDbContext :  DbContext
    {
        public FoodDbContext(DbContextOptions<FoodDbContext> options) : base(options)
        {

        }

        public DbSet<Category> Kind { get; set; }
        public DbSet<Customer> Customer { get; set; }
        public DbSet<Food> Foods { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Login> Login { get; set; }
        public DbSet<Payment> Payment { get; set; }
        public DbSet<OrderDetails> OrderDetails { get; set; }
        public DbSet<Address> Address { get; set; }
       public DbSet<OrderCartItems> OrderCartItems { get; set; }
        public DbSet<Restaurants> Restaurants { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                base.OnModelCreating(modelBuilder);



                //seed categories
                modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 1, CategoryName = "Chinese", CategoryDescription = "ygs" });
                modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 2, CategoryName = "North Indian", CategoryDescription = "ygs" });
                modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 3, CategoryName = "South Indian", CategoryDescription = "ygs" });
                modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 4, CategoryName = "Beverages", CategoryDescription = "ygs" });



            //seed food




            modelBuilder.Entity<Food>().HasData(new Food
            {
                CategoryId = 1,
                    FoodId = 1,
                FoodName = "Chilli-Patato",
                FoodPrice = 80,
                FoodDesc = "Very crispy and tasty"
            }); 



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    CategoryId = 2,
                    FoodId = 3,
                    FoodName = "Pizza",
                    FoodPrice = 50,
                    FoodDesc = "Very chizzy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    CategoryId = 3,
                    FoodId = 4,
                    FoodName = "Vada-Pao",
                    FoodPrice = 50,
                    FoodDesc = "Very spicy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    CategoryId = 4,
                    FoodId = 5,
                    FoodName = "Makhni Dal-",
                    FoodPrice = 50,
                    FoodDesc = "Very crispy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    CategoryId = 2,
                    FoodId = 6,
                    FoodName = "Burger",
                    FoodPrice = 50,
                    FoodDesc = "Very crispy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    CategoryId = 1,
                    FoodId = 2,
                    FoodName = "Noodles",
                    FoodPrice = 50,
                    FoodDesc = "Very crispy and tasty"
                });


            modelBuilder.Entity<Food>().HasData(new Food
            {
                CategoryId = 4,
                FoodId = 7,
                FoodName = "Sahee-Paneer with Naan",
                FoodPrice = 50,
                FoodDesc = "Very crispy and tasty"
            });

            //seed restaurant

            modelBuilder.Entity<Restaurants>().HasData(new Restaurants
            {
                RestId=101,
                RestName = "Bakers-Bite",
                RestMenu = "abc",
                RestImageUrl = "ABC",
                RestDesc = "IN KAVINAGAR",
                RestContactNumber = 12,
                Address = "Ghaziabad"
            });
            modelBuilder.Entity<Restaurants>().HasData(new Restaurants
            {
                RestId = 102,
                RestName = "Winkeys",
                RestMenu = "def",
                RestImageUrl="DEF",
                RestDesc = "IN KAVINAGAR",
                RestContactNumber = 12,
                Address = "Ghaziabad"
            });
            modelBuilder.Entity<Restaurants>().HasData(new Restaurants
            {
                RestId = 103,
                RestName = "Madan",
                RestMenu = "ghi",
                RestImageUrl = "GHI",
                RestDesc = "IN KAVINAGAR",
                RestContactNumber = 12,
                Address = "Ghaziabad"
            });


        }
        /*        public object OrderCartItem { get; internal set; }
                public object OrderCartItems { get; internal set; }*/

      
/*        public object OrderCartItem { get; internal set; }
        public object OrderCartItems { get; internal set; }*/

        public DbSet<FoodSystem.Models.OrderCart> OrderCart { get; set; }
        public IEnumerable<object> Food { get; internal set; }
    }
    }
