﻿using Microsoft.EntityFrameworkCore;
using KitchenAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace KitchenAPI.Models
{
    public class FoodDbContext : IdentityDbContext<IdentityUser>
    {
        public FoodDbContext(DbContextOptions<DbContext> options) : base(options)
        {
        }
        public DbSet<Category> Kind { get; set; }
        public DbSet<Customer> Cust { get; set; }
        public DbSet<Food> Foods { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Restaurants> Restaurants { get; set; }
        public object OrderCartItem { get; internal set; }
        public object OrderCartItems { get; internal set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);



            //seed categories
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 1, CategoryName = "Chinese" });
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 2, CategoryName = "North Indian" });
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 3, CategoryName = "South Indian" });
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 4, CategoryName = "Beverages" });



            //seed pies



            modelBuilder.Entity<Food>().HasData(new Food
            {
                FoodId = 1,
                FoodName = "Noodles",
                FoodPrice = 50,
                FoodDesc = "Very crispy and tasty"
            });



            modelBuilder.Entity<Food>().HasData(new Food
            {
                FoodId = 1,
                FoodName = "Chilli-Patato",
                FoodPrice = 80,
                FoodDesc = "Very crispy and tasty"
            });



            modelBuilder.Entity<Food>().HasData(new Food
            {
                FoodId = 2,
                FoodName = "Pizza",
                FoodPrice = 50,
                FoodDesc = "Very chizzy and tasty"
            });



            modelBuilder.Entity<Food>().HasData(new Food
            {
                FoodId = 2,
                FoodName = "Vada-Pao",
                FoodPrice = 50,
                FoodDesc = "Very spicy and tasty"
            });



            modelBuilder.Entity<Food>().HasData(new Food
            {
                FoodId = 3,
                FoodName = "Makhni Dal-",
                FoodPrice = 50,
                FoodDesc = "Very crispy and tasty"
            });



            modelBuilder.Entity<Food>().HasData(new Food
            {
                FoodId = 1,
                FoodName = "Noodles",
                FoodPrice = 50,
                FoodDesc = "Very crispy and tasty"
            });



            modelBuilder.Entity<Food>().HasData(new Food
            {
                FoodId = 1,
                FoodName = "Noodles",
                FoodPrice = 50,
                FoodDesc = "Very crispy and tasty"
            });



        }

        internal static FoodDbContext GetCart(IServiceProvider sp)
        {
            throw new NotImplementedException();
        }
    }
}