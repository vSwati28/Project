﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace KitchenAPI.Models
{
    public class OrderCart
    {
        private readonly FoodDbContext _appDbContext;

        public string OrderCartId { get; set; }

        public List<OrderCartItems> OrderCartItems { get; set; }

        private OrderCart(FoodDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public static OrderCart GetCart(IServiceProvider services)
        {
            ISession session = services.GetRequiredService<IHttpContextAccessor>()?
                .HttpContext.Session;

            var context = services.GetService<FoodDbContext>();

            string cartId = session.GetString("CartId") ?? Guid.NewGuid().ToString();

            session.SetString("CartId", cartId);

            return new OrderCart(context) { OrderCartId = cartId };
        }

       /* public void AddToCart(Food Food, int amount)
        {
            var orderCartItem =
                    _appDbContext.OrderCartItems.SingleOrDefault(
                        s => s.Food.FoodId == Food.FoodId && s.OrderCartId == OrderCartId);

            if (orderCartItem == null)
            {
                orderCartItem = new OrderCartItems
                {
                    OrderCartId = OrderCartId,
                    Food = Food,
                    Amount = 1
                };

                _appDbContext.OrderCartItems.Add(orderCartItem);
            }
            else
            {
                orderCartItem.Amount++;
            }
            _appDbContext.SaveChanges();
        }

        public int RemoveFromCart(Food Food)
        {
            var orderCartItem =
                    _appDbContext.OrderCartItems.SingleOrDefault(
                        s => s.Food.FoodId == Food.FoodId && s.OrderCartId == OrderCartId);

            var localAmount = 0;

            if (orderCartItem != null)
            {
                if (orderCartItem.Amount > 1)
                {
                    orderCartItem.Amount--;
                    localAmount = orderCartItem.Amount;
                }
                else
                {
                    _appDbContext.OrderCartItems.Remove(orderCartItem);
                }
            }

            _appDbContext.SaveChanges();

            return localAmount;
        }

        public List<OrderCartItems> GetOrderCartItems()
        {
            return OrderCartItems ??
                   (OrderCartItems =
                       _appDbContext.OrderCartItems.Where(c => c.OrderCartId == OrderCartId)
                           .Include(s => s.Food)
                           .ToList());
        }

        public void ClearCart()
        {
            var cartItems = _appDbContext
                .OrderCartItems
                .Where(cart => cart.OrderCartId == OrderCartId);

            _appDbContext.OrderCartItems.RemoveRange(cartItems);

            _appDbContext.SaveChanges();
        }

        public decimal GetOrderCartTotal()
        {
            var total = _appDbContext.OrderCartItems.Where(c => c.OrderCartId == OrderCartId)
                .Select(c => c.Food.FoodPrice * c.Amount).Sum();
            return total;
        }*/
    }
}
