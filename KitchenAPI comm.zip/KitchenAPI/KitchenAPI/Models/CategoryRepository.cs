﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KitchenAPI.Models
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly FoodDbContext _appDbContext;

        public CategoryRepository(FoodDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Category> AllCategories => _appDbContext.Kind;

    }
}
