﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace KitchenAPI.Models
{
    public interface IFoodRepository
    {

        IEnumerable<Food> AllFoods { get; }
    
        Food GetFoodById(int FoodId);
    }
}
