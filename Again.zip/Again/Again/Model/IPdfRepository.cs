﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Again.Model
{
    public interface IPdfRepository<T>
    {
        IEnumerable<T> GetAllPdf();
    }
}
