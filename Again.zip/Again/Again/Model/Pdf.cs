﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Again.Model
{
    public class Pdf
    {
        [Key]

        public string PdfId { get; set; }  
    }
}
