﻿using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocRead.Model
{
    public class PdfsController  
    {
        // readonly PdfContext _pdfContext;
        private readonly IPdfRepository<Pdf> _pdfRepository;

        /* public PdfRepository(PdfContext context)
         {
             _pdfContext = context;
         }*/

        public PdfsController(IPdfRepository<Pdf> PdfRepository)
        {
            _pdfRepository = PdfRepository;
        }
        public string ReadPdf(string Path)
        {
            StringBuilder text = new StringBuilder();
            try
            {

                //PdfReader reader = new PdfReader("C:\\\\Users\\Swati\\Downloads\\PHYSICS CERTIFICATE-edited.pdf");
                PdfReader reader = new PdfReader(Path);

                {
                    for (int i = 1; i <= reader.NumberOfPages; i++)
                    {
                        text.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                    }
                }

                //Console.WriteLine(text.ToString());
                return text.ToString();

            }
            catch (Exception e)
            {
                return "e";

            }
            // return text.ToString();
        }

        public string GetPdf(string Path)
        {
            return ReadPdf(Path);
        }
    }
}
