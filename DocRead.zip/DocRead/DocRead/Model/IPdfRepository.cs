﻿using System.Collections.Generic;

namespace DocRead.Model
{
    public interface IPdfRepository<Pdf>
    {
        IEnumerable<Pdf> GetAllPdf();
        Pdf ReadPdf(string Path);
    }
}