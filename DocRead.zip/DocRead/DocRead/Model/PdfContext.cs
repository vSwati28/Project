﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocRead.Model
{
    public class PdfContext: DbContext
    {
        public PdfContext(DbContextOptions<PdfContext> options)
            : base(options)
    {
    }

    public DbSet<Pdf> Pdfs { get; set; }
}
}
