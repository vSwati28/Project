﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DocRead.Model;

namespace DocRead.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PdfsController : ControllerBase
    {
        private readonly PdfContext _context;

        /* public PdfsController(PdfContext context)
         {
             _context = context;
         }*/
        private readonly IPdfRepository<Pdf> _pdfRepository;
        public PdfsController(IPdfRepository<Pdf> PdfRepository)
        {
            _pdfRepository = PdfRepository;
        }
        public void GetPdf(string Path)
        {
            IEnumerable<Pdf> pdf = _pdfRepository.GetAllPdf();
          //  return pdf;
        }
        // GET: api/Pdfs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Pdf>>> GetPdfs()
        {
            return await _context.Pdfs.ToListAsync();
        }

        // GET: api/Pdfs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Pdf>> GetPdf(long id)
        {
            var pdf = await _context.Pdfs.FindAsync(id);

            if (pdf == null)
            {
                return NotFound();
            }

            return pdf;
        }

        // PUT: api/Pdfs/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPdf(long id, Pdf pdf)
        {
            if (id != pdf.Id)
            {
                return BadRequest();
            }

            _context.Entry(pdf).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PdfExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Pdfs
        [HttpPost]
        public async Task<ActionResult<Pdf>> PostPdf(Pdf pdf)
        {
            _context.Pdfs.Add(pdf);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPdf", new { id = pdf.Id }, pdf);
        }

        // DELETE: api/Pdfs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Pdf>> DeletePdf(long id)
        {
            var pdf = await _context.Pdfs.FindAsync(id);
            if (pdf == null)
            {
                return NotFound();
            }

            _context.Pdfs.Remove(pdf);
            await _context.SaveChangesAsync();

            return pdf;
        }

        private bool PdfExists(long id)
        {
            return _context.Pdfs.Any(e => e.Id == id);
        }
    }
}
