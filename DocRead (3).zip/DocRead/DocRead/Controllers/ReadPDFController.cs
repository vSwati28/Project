﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DocRead.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DocRead.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReadPDFController : ControllerBase
    {
        private readonly IPdfRepository _pdfRepository;
        private readonly PdfContext _context;
        public ReadPDFController(IPdfRepository PdfRepository, PdfContext context)
        {

            _pdfRepository = PdfRepository;
            _context = context;

        }        // GET: api/ReadPDF
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/ReadPDF/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }
        [HttpGet]
        public async Task<ActionResult<Pdf>> GetPDF()
        {
            String path = " C:\\\\Users\\Swati\\Downloads\\PHYSICS CERTIFICATE-edited.pdf";
            var pdf = _pdfRepository.ReadPdf(path);
            return pdf;

        }
        // POST: api/ReadPDF
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/ReadPDF/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
