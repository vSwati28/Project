﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class FoodDbContext :  DbContext
    {
        public FoodDbContext(DbContextOptions<FoodDbContext> options) : base(options)
        {

        }

        public DbSet<Category> Kind { get; set; }
            public DbSet<Customer> Cust { get; set; }
            public DbSet<Food> Foods { get; set; }
            public DbSet<Order> Orders { get; set; }
            public DbSet<Restaurants> Restaurants { get; set; }
            public object OrderCartItem { get; internal set; }
            public object OrderCartItems { get; internal set; }

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                base.OnModelCreating(modelBuilder);



                //seed categories
                modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 1, CategoryName = "Chinese", CategoryDescription = "ygs" });
                modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 2, CategoryName = "North Indian", CategoryDescription = "ygs" });
                modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 3, CategoryName = "South Indian", CategoryDescription = "ygs" });
                modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 4, CategoryName = "Beverages", CategoryDescription = "ygs" });



                //seed food



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    FoodId = 7,
                    FoodName = "Noodles",
                    FoodPrice = 50,
                    FoodDesc = "Very crispy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    FoodId = 1,
                    FoodName = "Chilli-Patato",
                    FoodPrice = 80,
                    FoodDesc = "Very crispy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    FoodId = 2,
                    FoodName = "Pizza",
                    FoodPrice = 50,
                    FoodDesc = "Very chizzy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    FoodId = 3,
                    FoodName = "Vada-Pao",
                    FoodPrice = 50,
                    FoodDesc = "Very spicy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    FoodId = 4,
                    FoodName = "Makhni Dal-",
                    FoodPrice = 50,
                    FoodDesc = "Very crispy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    FoodId = 5,
                    FoodName = "Noodles",
                    FoodPrice = 50,
                    FoodDesc = "Very crispy and tasty"
                });



                modelBuilder.Entity<Food>().HasData(new Food
                {
                    FoodId = 6,
                    FoodName = "Noodles",
                    FoodPrice = 50,
                    FoodDesc = "Very crispy and tasty"
                });



            }
        }
    }
