﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Again.Model
{
    public interface IPdfRepository<Pdfs> 
    {
        IEnumerable<Pdfs> GetAllPdf();
        Pdf ReadPdf(string Path);
    }
}
