﻿using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Again.Model
{
    public class PdfRepository
    {
        readonly PdfContext _pdfContext;


        public PdfRepository(PdfContext context)
        {
            _pdfContext = context;
        }
        public IEnumerable<Pdf> GetAllPdf()
        {
            return _pdfContext.Pdfs.ToList();
        }
        public string ReadPdf(string Path)
        {
            StringBuilder text = new StringBuilder();
            try
            {

                //PdfReader reader = new PdfReader("C:\\\\Users\\Swati\\Downloads\\PHYSICS CERTIFICATE-edited.pdf");
                PdfReader reader = new PdfReader(Path);

                {
                    for (int i = 1; i <= reader.NumberOfPages; i++)
                    {
                        text.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                    }
                }

                //Console.WriteLine(text.ToString());
                return text.ToString();

            }
            catch (Exception e)
            {
                return "e";

            }
           // return text.ToString();
        }
         
        public string GetPdf(string Path)
        {
            return ReadPdf( Path);
        }
    }
}

