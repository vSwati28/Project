﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Again.Model;

namespace Again.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PdfsController : ControllerBase
    {
        private readonly PdfContext _context;

        public PdfsController(PdfContext context)
        {
            _context = context;
        }

        // GET: api/Pdfs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Pdf>>> GetPdfs()
        {
            return await _context.Pdfs.ToListAsync();
        }

        // GET: api/Pdfs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Pdf>> GetPdf(string id)
        {
            var pdf = await _context.Pdfs.FindAsync(id);

            if (pdf == null)
            {
                return NotFound();
            }

            return pdf;
        }

        // PUT: api/Pdfs/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPdf(string id, Pdf pdf)
        {
            if (id != pdf.PdfId)
            {
                return BadRequest();
            }

            _context.Entry(pdf).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PdfExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Pdfs
        [HttpPost]
        public async Task<ActionResult<Pdf>> PostPdf(Pdf pdf)
        {
            _context.Pdfs.Add(pdf);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPdf", new { id = pdf.PdfId }, pdf);
        }

        // DELETE: api/Pdfs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Pdf>> DeletePdf(string id)
        {
            var pdf = await _context.Pdfs.FindAsync(id);
            if (pdf == null)
            {
                return NotFound();
            }

            _context.Pdfs.Remove(pdf);
            await _context.SaveChangesAsync();

            return pdf;
        }

        private bool PdfExists(string id)
        {
            return _context.Pdfs.Any(e => e.PdfId == id);
        }
    }
}
