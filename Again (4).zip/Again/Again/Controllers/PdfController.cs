﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Again.Model;
using Microsoft.AspNetCore.Mvc;

namespace Again.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PdfController : ControllerBase
    {

        private readonly IPdfRepository<Pdf> _pdfRepository;

        *//*public PdfController(IPdfRepository<Pdf> PdfRepository)
        {
            _pdfRepository = PdfRepository;
        }*//*
        // GET api/Pdf
       [HttpGet]
      // [Route("GetAllPdf")]
       [Route("GetPdf")]
       [HttpGet("{PdfId,Path}")]
       public void GetPdf(string Path)
       {
            IEnumerable<Pdf> pdfs = _pdfRepository.GetAllPdf();
           // return pdfs;
       }
      *//*  public ActionResult GetAllPdf()
        {
            IEnumerable<Pdf> pdfs = _pdfRepository.GetAllPdf();

            return Ok(pdfs);
        }*//*
        //GET api/pdf/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int Path)
        {
            return "Path";
        }

        // POST api/pdf
        [HttpPost]
        public void Post([FromBody] string Path)
        {
        }

        // PUT api/pdf/5
        [HttpPut("{id}")]
        public void Put(int Pdfid, [FromBody] string value)
        {
        }

        // DELETE api/pdf/5
        [HttpDelete("{id}")]
        public void Delete(int Pdfid)
        {
        }


    }
}
*/