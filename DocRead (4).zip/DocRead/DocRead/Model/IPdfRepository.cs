﻿using System.Collections.Generic;

namespace DocRead.Model
{
    public interface IPdfRepository
    {
        IEnumerable<Pdf> GetAllPdf();
        string ReadPdf(string Path);
    }
}