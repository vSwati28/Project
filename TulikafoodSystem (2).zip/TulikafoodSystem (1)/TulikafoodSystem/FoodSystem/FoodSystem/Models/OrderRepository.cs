﻿using FoodSystem.Controllers;
using KitchenAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodSystem.Models
{
    public class OrderRepository : IOrderRepository
    {
        private readonly FoodDbContext _appDbContext;
        private readonly OrderCart _OrderCart;



        public OrderRepository(FoodDbContext appDbContext, OrderCart OrderCart)
        {
            _appDbContext = appDbContext;
            _OrderCart = OrderCart;
        }



        public void CreateOrder(Order order)
        {
            order.OrderPlaced = DateTime.Now;

            var OrderCartItems = _OrderCart.OrderCartItems;

            //order.OrderTotal = _OrderCart.GetOrderCartTotal();
            order.OrderDetail = new List<OrderDetails>();//adding the order with its details

            foreach (var OrderCartItem in OrderCartItems)
            {
                var orderDetails = new OrderDetails
                {
                    Amount = OrderCartItem.Amount,
                    FoodId = OrderCartItem.Food.FoodId,
                    Price = OrderCartItem.Food.FoodPrice
                };


                order.OrderDetail.Add(orderDetails);
            }


            _appDbContext.SaveChanges();
        }


    }
}
